<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>package</title>
    <!--Swipper css link-->
    <link
  rel="stylesheet"href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <!--font awesome cdn link-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <!--custom file link-->
    <link rel="stylesheet" href="style.css">
</head>
<body>
<!--header section start-->

<section class="header">
    <a href="home.php" class="logo">Travel</a>
    <nav class="navbar">
        <a href="home.php">home</a>
        <a href="about.php">about</a>
        <a href="package.php">package</a>
        <a href="services.php">services</a>
        <a href="book.php">book</a>
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>
</section>




<!--header section end-->
<!--home section start-->
<section class="home">
    <div class="swiper home-slider">
        <div class="swiper-wrapper">

            <div class="swiper-slide slide" style="background: url(images/services2.avif) no-repeat">
                <div class="content">
                    <span>explore,discover ,travel</span>
                    <h3>Explore Top Destinations </h3>
                    <a href="package.php" class="btn">discover more</a>
                </div>
            </div>
            <div class="swiper-slide slide" style="background: url(images/home\ slide2.avif) no-repeat">
                <div class="content">
                    <span>explore,discover ,travel</span>
                    <h3>discover the new place</h3>
                    <a href="package.php" class="btn">discover more</a>
                </div>
            </div>
            <div class="swiper-slide slide" style="background: url(images/home\ slide3.avif) no-repeat">
                <div class="content">
                    <span>explore,discover ,travel</span>
                    <h3>make your tour worthwhile</h3>
                    <a href="package.php" class="btn">discover more</a>
                </div>
            </div>
        </div>

        <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
    </div>
</section>
<!-----------------------home section end------------------------>
<!---<div class="heading" style="background:url(images/services.jpg) no-repeat">
    <h1>services
    </h1>
</div>-------->
<!-----------------header section end---------->
<!----------------adeventur section------------------->
<section class="packages">
    <h1 class="heading-title">best place for Adventure </h1>
    <div class="box-container">
        <div class="box">
            <div class="image">
                <img src="images/adventure.avif" alt="">
            </div>
            <div class="content">
                <h3>Dubai</h3>
                <p>Nestled amidst the rolling hills and misty valleys of picturesque Western Ghats,
                     this quaint hill station near Nashik will charm you with its jaw-dropping scenery and cascading waterfalls.</p>
                     <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/adventure4.cms" alt="">
            </div>
            <div class="content">
                <h3>River rafting, Rishikesh</h3>
                <p>River rafting is another adrenaline pumping sport that can be enjoyed in Rishikesh. The fun rapid waves here attract every water adventure lover. With so many interesting sports 
                    opportunities, Rishikesh is one of the best adventure destinations in India.</p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/adventure3.jpg" alt="">
            </div>
            <div class="content">
                <h3>Paragliding, Bir Billing</h3>
                <p>Bir Billing in Himachal Pradesh is a hotspot for adventurers. The village is known for hosting the 
                    international paragliding world cup championship! The destination offers the opportunity for paragliding and 
                    adventure seekers from all over the world visit here to experience the sport.</p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/adventure5.avif" alt="">
            </div>
            <div class="content">
                <h3>Thirunelli Temple</h3>
                <p>Set amidst blue-green hills and forests, is the Thirunelli Temple, dedicated to Lord Vishnu.
                     The ancient temple exhibits an incomparable tranquil aura.</p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/adventure6.avif" alt="">
            </div>
            <div class="content">
                <h3>Kuruva Island</h3>
                <p>Sprawling over 950 acres, Kuruva is a group of islands housing dense forests rich 
                    in flora and fauna, most of which are rare in nature.</p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/adventure7.avif" alt="">
            </div>
            <div class="content">
                <h3>Banasura Sagar Dam</h3>
                <p>The largest earthen dam in India and the second-largest one in Asia, Banasura Sagar Dam provides
                    irrigation, electricity and drinking water to the areas nearby.</p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/Kodaikanal.avif" alt="">
            </div>
            <div class="content">
                <h3>Kodaikanal</h3>
                <p>Spread across the scenic Western Ghats at an altitude of 7,200 feet, 
                    Kodaikanal is a beautiful hill station in Tamil Nadu with wooded slopes, gigantic trees, and misty green meadows.</p>
                    <h3>Price: <span>$60</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
</section>
<section class="packages">
    <h1 class="heading-title">best place for off road</h1>
    <div class="box-container">
        <div class="box">
            <div class="image">
                <img src="images/off road1.webp" alt="">
            </div>
            <div class="content">
                <h3>Foothills Of Aravalli</h3>
                <p>Open off-road tracks are best liked rugged and chunky, and the foothills of Aravallis 
                    are exactly that. The fact that it's a little away 
                    from the main city attracts nature-lovers, off-roaders and the adventurous. </p>
                     <h3>Price: <span>$50</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/off road2.webp" alt="">
            </div>
            <div class="content">
                <h3>Bandhwari Village</h3>
                <p>Bandhwari is a village popularly known for its lush green forest cover. Many cyclists and bikers 
                    have created open tracks here that you can follow. 
                    But if you're feeling too adventurous, you can find your own trail route too.</p>
                    <h3>Price: <span>$80</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>


        <div class="box">
            <div class="image">
                <img src="images/off road3.webp" alt="">
            </div>
            <div class="content">
                <h3>Summer Sprint</h3>
                <p>Located right next to the toll road on the GFR (Gurgaon-Faridabad Road), Summer Sprint is one the most visited open tracks in Gurgaon. 
                    You shouldn't have trouble finding it if you're coming from Damdama.</p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
    </section>
    <section class="packages">
    <h1 class="heading-title">best place for Camping place</h1>
    <div class="box-container">
        <div class="box">
            <div class="image">
                <img src="images/Camping1.jpg" alt="">
            </div>
            <div class="content">
                <h3> Tso Moriri Lake, Ladakh</h3>
                <p>Tsomoriri Lake is the highest lake in the world and located in Ladakh. Camping here is the experience of a lifetime.
                     The lake is completely frozen during the winters and is an excitingly unique thing to witness. The best time to camp here
                     is during May to September and it is simply wonderful to spend time</p>
                     <h3>Price: <span>$120</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>

        
        <div class="box">
            <div class="image">
                <img src="images/camping2.jpg" alt="">
            </div>
            <div class="content">
                <h3>Rishikesh Valley camp, Rishikesh</h3>
                <p>When it comes to camping, Rishikesh Camping experience has to be on the list! This amazing Rishikesh
                     Valley camp is not only close to nature but also has a more spiritual connection. The tents here are styled in a hermit fashion and are designed to give you total aloof time. 
                     </p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>

        
        <div class="box">
            <div class="image">
                <img src="images/camping3.jpg" alt="">
            </div>
            <div class="content">
                <h3>Camp Exotica, Kullu</h3>
                <p>The Camp Exotica is a perfect weekend getaway option located in Kullu in the Manali district of Himachal Pradesh. The accommodation provided is world class and the tents simply leave you connecting with nature like never before.
                     The location of these tents is such that it gives a panoramic view of the surrounding mountains. </p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
    </section>
    <section class="packages">
    <h1 class="heading-title"> best place for Camp Fire place</h1>
    <div class="box-container">
        <div class="box">
            <div class="image">
                <img src="images/campfire1.webp" alt="">
            </div>
            <div class="content">
                <h3> Kullu & Manali</h3>
                <p>A popular location for camping by the river, surrounded by the snow clad hills, Kullu is a 
                    picturesque location for a bonfire night with friends</p>
                     <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
        
        <div class="box">
            <div class="image">
                <img src="images/campfire2.webp" alt="">
            </div>
            <div class="content">
                <h3>McLeodganj & Kasauli</h3>
                <p>For an adventurous bonfire night, drive upto the nearest hills in your vicinity, tag your friends along and stay overnight around the fire. Both Kasauli & Mcleodganj are few hours
                     away from Delhi, and these snow clad hills have a picturesque aura in winters.</p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
        
        <div class="box">
            <div class="image">
                <img src="images/campfire3.webp" alt="">
            </div>
            <div class="content">
                <h3>Jaipur</h3>
                <p>Set up a camp in jungle or the rural areas surrounding the Amber fort and enjoy the bonfire adventures with folk dances, 
                    safaris and your best pals.</p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
    </section>

    <section class="packages">
    <h1 class="heading-title"> best place for Trekking place</h1>
    <div class="box-container">
        <div class="box">
            <div class="image">
                <img src="images/treeking1.avif" alt="">
            </div>
            <div class="content">
                <h3>Coonoor</h3>
                <p>Blessed with stunning flora and fauna of the Nilgiris Hills, Coonoor is the quintessential hill station with viewpoints, waterfalls, lakes,
                    gardens, tea estates and colonial-style architecture</p>
                     <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/trekimg2.avif" alt="">
            </div>
            <div class="content">
                <h3>Kasauli</h3>
                <p>A quintessential hill station surrounded by pine and oak forests with scenic viewpoints and colonial-era landmarks,
                     Kasauli stands at an altitude of 1,800 metres.</p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/treeking3.avif" alt="">
            </div>
            <div class="content">
                <h3>Nandi Hills</h3>
                <p>Perched at a height of 4,851 feet above sea level, Nandi Hills are the former summer retreat of Tipu Sultan. 
                    This ancient hill fortress is scattered with monuments and shrines.</p>
                    <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>



        </section>
    <section class="packages">
    <h1 class="heading-title">Tour Guide</h1>
    <div class="box-container">
        <div class="box">
            <div class="image">
                <img src="images/igatpuri.avif" alt="">
            </div>
            <div class="content">
                <h3>Igatpuri</h3>
                <p>Nestled amidst the rolling hills and misty valleys of picturesque Western Ghats,
                     this quaint hill station near Nashik will charm you with its jaw-dropping scenery and cascading waterfalls.</p>
                     <h3>Price: <span>$100</span></h3>
                    <a href="explore.php" class="btn">explore</a>
                <a href="book.php" class="btn">book now</a>
            </div>
        </div>
    </section>
















































<!--fotter section-->
<section class="footer">
    <div class="box-container">
        <div class="box">
            <h3>Quick links</h3>
         <a href="home.php"><i class="fas fa-angle-right" ></i>home</a>
        <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
        <a href="package.php"><i class="fas fa-angle-right"></i>package</a>
        <a href="services.php"><i class= "fas fa-angle-right"></i>services</a>
        <a href="book.php"><i class= "fas fa-angle-right"></i>book</a>
        

        </div>

        <div class="box">
            <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i>ask questions</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i>about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i>privecy,policy</a>
         <a href="#"> <i class="fas fa-angle-right"></i>terms of use</a>
    </div>

    <div class="box">
        <h3>contact info</h3>
     <a href="#"> <i class="fas fa-phone"></i>+91-9931-88-5261 </a>
     <a href="#"> <i class="fas fa-phone"></i>+9931-88-5261 </a>
     <a href="#"> <i class="fas fa-envelope"></i>ravi8287063264@gmail.com </a>
     <a href="#"> <i class="fas fa-map"></i>Siwan, Bihar-841413 </a>

    </div>
    <div class="box">
        <h3>folow us </h3>
        <a href="#"> <i class="fab fa-facebook"></i>facebook </a>
        <a href="#"> <i class="fab fa-twitter"></i>twitter</a>
        <a href="#"> <i class="fab fa-instagram"></i>instagram</a>
        <a href="#"> <i class="fab fa-linkedin"></i>linkedin </a>
    </div>
</div>
    <div class="credit">created by <span>Raviranjan Kumar</span> | all rights reserved!</div>
</section>
<!--footer section end-->
<!--swipper js link-->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <!--custom js file link-->
    <script src="script.js"></script>
    <!--swipper js link end- ->
    
</body>
</html>