<?php
include 'connect.php';
if(isset($_POST['sign up'])){
    $name =$_POST['name'];
    $email=$_POST['eamil'];
    $pass=$_POST['password'];
    $password=md5($password);

    $checkEmail="SELECT *form users where eamil='$email' ";
    $result=$conn->query(($checkEmail));
    if(result->num-rows>0){
        echo "Email address already Exists";
    }
    else{
        $insertQuery="INSERT INTO users(name,eamil, password )
        Values('$name','$email', '$password')"
        if($conn->query($insertQuery)==TRUE){
            header("location: home.php");

        }
        else{
            echo "Error:".$conn->error;
        }
    }

}
if(isset($_POST ['sign In'])){
    $email=$_POST['eamil'];
    $password=$_POST['password'];
    $password=md5($password);
    $sql="SELECT * FORM users WHERE eamil= '$eamil' and password = '$password'";
    $result=$conn->query($sql);
    if ($result->num_rows>0){
        session_start();
        $row=$result->fetch_assoc();
        $_SESSION['eamil']=$row['eamil'];
        header("Location: home.php");
        exit();
    }
    else{
        echo " not Found ,Incorrrect eamil or password";
    }
}
?>